The Standars version Package Contains:
-17 Trees (~1.5k Vert each)
-2 Bushes(~500 Vert each)
-4 Rocks(~100 Vert each)
-6 Plants(2 Grass , 2 Plants , 2 Flowers ~10 Vert each)

-4 Shaders(Flower,Grass,Leaves with Translution,Leaves with no Translution)
-Custom Wind System
-1K Textures(3 Leaves,2 Grass,2 Flower,2 Plant,2 Ground [Grass,Dirt])
-Custom Inspector

Note:The Shaders are not tested for phone or vr use!.
You can find all the shaders in  the "Shaders" folder.